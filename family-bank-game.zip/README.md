# Family Bank — Ищи-найди

Полный исходный модуль игры (HTML + CSS + JS, без сборки).

## Что внутри

```
game/
  index.html          ← точка входа, откройте в браузере
  game.js             ← 1117 строк движка (камера, раунд, proof, API)
  game.css            ← 663 строки стилей
  js/config.js        ← константы
  js/data.js          ← 39 предметов + 6 карт + точки спавна
  assets/maps/        ← 6 панорам
  assets/objects/     ← 39 PNG
  assets/ui/hero.jpg
  assets/fonts/
  INTEGRATION.md      ← как встроить в Family Bank
  GAME_CONFIG.md
  CONTENTS.txt        ← полный список файлов
  docs/               ← исходные ТЗ
```

Код не минифицирован. Картинки лежат рядом, внешних URL нет.

На телефоне: распакуйте ZIP, откройте `game/index.html` в Safari / Chrome.
Для интеграции в Mini App читайте `game/INTEGRATION.md`.
